// ============================================================================
// CONSTELLATION EFFECT - MODULAR ASSET
// ============================================================================

class ConstellationEffect {
    constructor(options = {}) {
        // Default configuration
        this.config = {
            selector: '#particle-canvas',
            particleCount: 50,
            connectionDistance: 150,
            mouseDistance: 150,
            colors: [
                '#DC2626', // Red
                '#EA580C', // Orange
                '#FBBF24', // Yellow
                '#16A34A', // Green
                '#2563EB', // Blue
                '#F9FAFB'  // White
            ],
            ...options // Override with user options
        };

        this.canvas = document.querySelector(this.config.selector);
        if (!this.canvas) {
            console.error(`ConstellationEffect: Canvas not found with selector "${this.config.selector}"`);
            return;
        }

        this.ctx = this.canvas.getContext('2d');
        this.particles = [];
        this.mouse = { x: null, y: null };
        this.isPaused = false;
        this.lastFrameTime = performance.now();
        this.fps = 60;
        this.animationId = null;

        this.init();
    }

    init() {
        this.resizeCanvas();
        this.createParticles();
        this.setupEventListeners();
        this.animate();
        console.log('✨ Constellation Effect Initialized');
    }

    resizeCanvas() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
    }

    setupEventListeners() {
        window.addEventListener('resize', () => this.resizeCanvas());

        window.addEventListener('mousemove', (e) => {
            this.mouse.x = e.clientX;
            this.mouse.y = e.clientY;
        });

        window.addEventListener('mouseleave', () => {
            this.mouse.x = null;
            this.mouse.y = null;
        });

        window.addEventListener('touchmove', (e) => {
            if (e.touches.length > 0) {
                this.mouse.x = e.touches[0].clientX;
                this.mouse.y = e.touches[0].clientY;
            }
        });

        window.addEventListener('touchend', () => {
            this.mouse.x = null;
            this.mouse.y = null;
        });
    }

    createParticles() {
        this.particles = [];
        for (let i = 0; i < this.config.particleCount; i++) {
            this.particles.push(new Particle(this));
        }
    }

    reset() {
        this.createParticles();
    }

    togglePause() {
        this.isPaused = !this.isPaused;
        if (!this.isPaused) {
            this.animate();
        } else {
            cancelAnimationFrame(this.animationId);
        }
        return this.isPaused;
    }

    animate() {
        if (this.isPaused) return;

        const now = performance.now();
        const delta = now - this.lastFrameTime;
        this.fps = Math.round(1000 / delta);
        this.lastFrameTime = now;

        // Dispatch custom event for UI updates if needed
        this.canvas.dispatchEvent(new CustomEvent('constellation:update', {
            detail: { fps: this.fps, particleCount: this.particles.length }
        }));

        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        this.particles.forEach(particle => {
            particle.update();
            particle.draw();
        });

        this.connectParticles();

        this.animationId = requestAnimationFrame(() => this.animate());
    }

    connectParticles() {
        for (let i = 0; i < this.particles.length; i++) {
            for (let j = i + 1; j < this.particles.length; j++) {
                const p1 = this.particles[i];
                const p2 = this.particles[j];
                const dx = p1.x - p2.x;
                const dy = p1.y - p2.y;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance < this.config.connectionDistance) {
                    const opacity = 1 - (distance / this.config.connectionDistance);
                    this.ctx.strokeStyle = `rgba(139, 92, 246, ${opacity * 0.3})`;
                    this.ctx.lineWidth = 1;
                    this.ctx.beginPath();
                    this.ctx.moveTo(p1.x, p1.y);
                    this.ctx.lineTo(p2.x, p2.y);
                    this.ctx.stroke();
                }
            }
        }
    }
}

class Particle {
    constructor(system) {
        this.system = system;
        this.reset();
    }

    reset() {
        this.x = Math.random() * this.system.canvas.width;
        this.y = Math.random() * this.system.canvas.height;
        this.size = Math.random() * 4 + 2;
        this.speedX = (Math.random() - 0.5) * 2;
        this.speedY = (Math.random() - 0.5) * 2;
        this.color = this.system.config.colors[Math.floor(Math.random() * this.system.config.colors.length)];
        this.rotation = Math.random() * Math.PI * 2;
        this.rotationSpeed = (Math.random() - 0.5) * 0.02;
    }

    update() {
        if (this.system.mouse.x !== null && this.system.mouse.y !== null) {
            const dx = this.system.mouse.x - this.x;
            const dy = this.system.mouse.y - this.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            const maxDistance = this.system.config.mouseDistance;

            if (distance < maxDistance) {
                const force = (maxDistance - distance) / maxDistance;
                const angle = Math.atan2(dy, dx);
                this.speedX -= Math.cos(angle) * force * 0.5;
                this.speedY -= Math.sin(angle) * force * 0.5;
            }
        }

        this.x += this.speedX;
        this.y += this.speedY;
        this.rotation += this.rotationSpeed;

        this.speedX *= 0.98;
        this.speedY *= 0.98;

        if (this.x < 0 || this.x > this.system.canvas.width) {
            this.speedX *= -1;
            this.x = Math.max(0, Math.min(this.system.canvas.width, this.x));
        }
        if (this.y < 0 || this.y > this.system.canvas.height) {
            this.speedY *= -1;
            this.y = Math.max(0, Math.min(this.system.canvas.height, this.y));
        }

        const minSpeed = 0.1;
        if (Math.abs(this.speedX) < minSpeed) this.speedX = (Math.random() - 0.5) * minSpeed * 2;
        if (Math.abs(this.speedY) < minSpeed) this.speedY = (Math.random() - 0.5) * minSpeed * 2;
    }

    draw() {
        const ctx = this.system.ctx;
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.rotation);

        const halfSize = this.size / 2;

        ctx.fillStyle = this.color;
        ctx.fillRect(-halfSize, -halfSize, this.size, this.size);

        ctx.fillStyle = this.lightenColor(this.color, 20);
        ctx.beginPath();
        ctx.moveTo(-halfSize, -halfSize);
        ctx.lineTo(0, -halfSize - halfSize * 0.5);
        ctx.lineTo(halfSize, -halfSize);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = this.darkenColor(this.color, 20);
        ctx.beginPath();
        ctx.moveTo(halfSize, -halfSize);
        ctx.lineTo(halfSize + halfSize * 0.5, 0);
        ctx.lineTo(halfSize, halfSize);
        ctx.closePath();
        ctx.fill();

        ctx.shadowBlur = 10;
        ctx.shadowColor = this.color;

        ctx.restore();
    }

    lightenColor(color, percent) {
        const num = parseInt(color.replace('#', ''), 16);
        const amt = Math.round(2.55 * percent);
        const R = Math.min(255, (num >> 16) + amt);
        const G = Math.min(255, ((num >> 8) & 0x00FF) + amt);
        const B = Math.min(255, (num & 0x0000FF) + amt);
        return `rgb(${R}, ${G}, ${B})`;
    }

    darkenColor(color, percent) {
        const num = parseInt(color.replace('#', ''), 16);
        const amt = Math.round(2.55 * percent);
        const R = Math.max(0, (num >> 16) - amt);
        const G = Math.max(0, ((num >> 8) & 0x00FF) - amt);
        const B = Math.max(0, (num & 0x0000FF) - amt);
        return `rgb(${R}, ${G}, ${B})`;
    }
}


// Expose to window for global usage
window.ConstellationEffect = ConstellationEffect;
