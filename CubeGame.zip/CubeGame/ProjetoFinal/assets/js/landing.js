document.addEventListener('DOMContentLoaded', () => {
    // Navbar Scroll Effect Removed

    // Smooth Scroll for Navigation Links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });

                // Update active link
                document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
                this.classList.add('active');
            }
        });
    });

    // Intersection Observer for Fade-up Animations
    const observerOptions = {
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animationPlayState = 'running';
                entry.target.style.opacity = '1'; // Force opacity
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    document.querySelectorAll('.animate-fade-up').forEach(el => {
        // Don't pause initially to avoid black screen if JS fails or observer misses
        // el.style.animationPlayState = 'paused'; 
        // Instead, we let them run, or we ensure they are visible.
        // But if we want the effect, we must pause.
        // Let's try a safer approach: set opacity 1 after a timeout fallback

        el.style.animationPlayState = 'paused';
        observer.observe(el);

        // Fallback: if not intersected in 1s, show anyway
        setTimeout(() => {
            if (getComputedStyle(el).opacity === '0') {
                el.style.animationPlayState = 'running';
                el.style.opacity = '1';
            }
        }, 1000);
    });
});
