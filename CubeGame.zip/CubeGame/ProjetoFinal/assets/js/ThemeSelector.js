export class ThemeSelector {
    constructor(themeManager) {
        this.themeManager = themeManager;
        this.modal = document.getElementById('theme-selector-modal');
        this.grid = this.modal.querySelector('.theme-grid');
        this.btnClose = document.getElementById('btn-close-theme');

        this.init();
    }

    init() {
        this.renderThemes();

        // Event Listeners
        this.btnClose.addEventListener('click', () => this.close());

        // Open button (needs to be attached in main.js or here if element exists)
        const btnOpen = document.getElementById('btn-theme');
        if (btnOpen) {
            btnOpen.addEventListener('click', () => this.open());
        }
    }

    renderThemes() {
        this.grid.innerHTML = '';
        const themes = this.themeManager.getThemes();
        const current = this.themeManager.getCurrentTheme();

        Object.entries(themes).forEach(([key, theme]) => {
            const el = document.createElement('div');
            el.className = `theme-option ${key === current ? 'active' : ''}`;
            el.dataset.theme = key;

            // Create 3D Cube Preview for Theme
            const preview = document.createElement('div');
            preview.className = 'theme-preview-3d';

            // Create 6 faces
            const faces = ['front', 'back', 'right', 'left', 'top', 'bottom'];
            faces.forEach(face => {
                const faceEl = document.createElement('div');
                faceEl.className = `cube-face face-${face}`;

                // Map faces to theme colors
                let color;
                switch (face) {
                    case 'front': color = theme.colors.F; break;
                    case 'back': color = theme.colors.B; break;
                    case 'right': color = theme.colors.R; break;
                    case 'left': color = theme.colors.L; break;
                    case 'top': color = theme.colors.U; break;
                    case 'bottom': color = theme.colors.D; break;
                    default: color = theme.colors.Core;
                }

                // Convert hex to string
                const colorStr = '#' + color.toString(16).padStart(6, '0');

                // Create a 3x3 grid for the face
                for (let i = 0; i < 9; i++) {
                    const cubie = document.createElement('div');
                    cubie.className = 'mini-cubie';
                    cubie.style.backgroundColor = colorStr;
                    faceEl.appendChild(cubie);
                }
                preview.appendChild(faceEl);
            });

            el.appendChild(preview);

            const label = document.createElement('span');
            label.className = 'theme-name';
            label.textContent = theme.name;
            el.appendChild(label);

            el.addEventListener('click', () => {
                this.themeManager.applyTheme(key);
                this.updateActiveState(key);
            });

            this.grid.appendChild(el);
        });
    }

    updateActiveState(activeKey) {
        const options = this.grid.querySelectorAll('.theme-option');
        options.forEach(opt => {
            if (opt.dataset.theme === activeKey) {
                opt.classList.add('active');
            } else {
                opt.classList.remove('active');
            }
        });
    }

    open() {
        this.modal.classList.remove('hidden');
        this.modal.classList.add('active');
    }

    close() {
        this.modal.classList.remove('active');
        this.modal.classList.add('hidden');
    }
}
