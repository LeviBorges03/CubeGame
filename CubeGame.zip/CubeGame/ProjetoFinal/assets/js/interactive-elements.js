// Simple Counter Animation for Stats
const animateValue = (obj, start, end, duration) => {
    let startTimestamp = null;
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        obj.innerHTML = Math.floor(progress * (end - start) + start);
        if (progress < 1) {
            window.requestAnimationFrame(step);
        }
    };
    window.requestAnimationFrame(step);
};

// Initialize counters when they come into view
const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            // Logic to trigger counters would go here if we had dynamic numbers
            // For now, this file is a placeholder for future complex interactions
            console.log('Stats section visible');
            statsObserver.unobserve(entry.target);
        }
    });
});

const statsSection = document.querySelector('#records');
if (statsSection) {
    statsObserver.observe(statsSection);
}
