export class PuzzleSelector {
    constructor(game) {
        this.game = game;
        this.modal = document.getElementById('puzzle-selector-modal');
        this.grid = this.modal.querySelector('.puzzle-grid');
        this.btnClose = document.getElementById('btn-close-selector');

        this.init();
    }

    init() {
        // Generate the HTML for puzzle options if not already present or to enhance them
        this.renderOptions();

        // Event Listeners
        this.btnClose.addEventListener('click', () => this.close());

        // Open button (attached in main.js)
        const btnOpen = document.getElementById('puzzle-label');
        if (btnOpen) {
            btnOpen.addEventListener('click', () => this.open());
        }
    }

    renderOptions() {
        // We will rebuild the grid to include the 3D CSS structure
        const sizes = [2, 3, 4, 5];
        this.grid.innerHTML = '';

        sizes.forEach(size => {
            const btn = document.createElement('button');
            btn.className = `puzzle-option ${size === this.game.currentSize ? 'active' : ''}`;
            btn.dataset.size = size;

            // Create 3D Cube Preview HTML
            const preview = document.createElement('div');
            preview.className = `puzzle-preview size-${size}`;

            // Create 6 faces
            const faces = ['front', 'back', 'right', 'left', 'top', 'bottom'];
            faces.forEach(face => {
                const faceEl = document.createElement('div');
                faceEl.className = `cube-face face-${face}`;

                // Add mini cubies
                const count = size * size;
                for (let i = 0; i < count; i++) {
                    const cubie = document.createElement('div');
                    cubie.className = 'mini-cubie';
                    faceEl.appendChild(cubie);
                }
                preview.appendChild(faceEl);
            });

            btn.appendChild(preview);

            const label = document.createElement('span');
            label.textContent = `${size}x${size}x${size}`;
            btn.appendChild(label);

            btn.addEventListener('click', () => {
                this.selectPuzzle(size);
            });

            this.grid.appendChild(btn);
        });
    }

    selectPuzzle(size) {
        if (this.game.currentSize === size) {
            this.close();
            return;
        }

        this.game.setPuzzle(size);

        // Update active state
        const options = this.grid.querySelectorAll('.puzzle-option');
        options.forEach(opt => {
            if (parseInt(opt.dataset.size) === size) {
                opt.classList.add('active');
            } else {
                opt.classList.remove('active');
            }
        });

        this.close();
    }

    open() {
        this.modal.classList.remove('hidden');
        this.modal.classList.add('active');
    }

    close() {
        this.modal.classList.remove('active');
        this.modal.classList.add('hidden');
    }
}
