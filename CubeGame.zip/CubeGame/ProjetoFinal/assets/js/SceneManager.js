import * as THREE from 'three';

export class SceneManager {
    constructor(container) {
        this.container = container;
        this.scene = new THREE.Scene();
        // Removed solid background to allow for transparent canvas or custom background mesh
        // this.scene.background = new THREE.Color('#1F1D2B'); 

        this.camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 100);
        this.camera.position.set(5, 5, 7);
        this.camera.lookAt(0, 0, 0);

        this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(window.devicePixelRatio);
        // Set clear color to transparent to reveal constellation canvas
        this.renderer.setClearColor(0x000000, 0);
        this.container.appendChild(this.renderer.domElement);

        this.addLights();
        // this.createBackground(); // Disabled to use CSS/Canvas background

        window.addEventListener('resize', this.onWindowResize.bind(this));
    }

    addLights() {
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
        this.scene.add(ambientLight);

        const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
        dirLight.position.set(10, 20, 10);
        this.scene.add(dirLight);

        const backLight = new THREE.DirectionalLight(0xffffff, 0.3);
        backLight.position.set(-10, -10, -10);
        this.scene.add(backLight);
    }

    setBackground(backgroundDef) {
        // Update clear color
        if (backgroundDef.bg) {
            // this.renderer.setClearColor(backgroundDef.bg, 1); // Disabled to keep background transparent
        }

        // Update particles
        if (this.particles && backgroundDef.type === 'particles') {
            const colors = this.particles.geometry.attributes.color;
            const count = colors.count;

            const c1 = new THREE.Color(backgroundDef.color1);
            const c2 = new THREE.Color(backgroundDef.color2);

            for (let i = 0; i < count; i++) {
                const mixedColor = Math.random() > 0.5 ? c1 : c2;
                colors.setXYZ(i, mixedColor.r, mixedColor.g, mixedColor.b);
            }

            colors.needsUpdate = true;
            this.particles.visible = true;
        } else if (this.particles) {
            this.particles.visible = false;
        }
    }

    createBackground() {
        // Create a particle system for the background
        const particlesGeometry = new THREE.BufferGeometry();
        const count = 2000;

        const positions = new Float32Array(count * 3);
        const colors = new Float32Array(count * 3);

        const color1 = new THREE.Color(0x6C5DD3); // Primary Purple
        const color2 = new THREE.Color(0x00D4FF); // Cyan accent

        for (let i = 0; i < count * 3; i += 3) {
            // Random positions in a large sphere
            const r = 40 + Math.random() * 40;
            const theta = Math.random() * Math.PI * 2;
            const phi = Math.acos(2 * Math.random() - 1);

            positions[i] = r * Math.sin(phi) * Math.cos(theta);
            positions[i + 1] = r * Math.sin(phi) * Math.sin(theta);
            positions[i + 2] = r * Math.cos(phi);

            // Mix colors
            const mixedColor = Math.random() > 0.5 ? color1 : color2;
            colors[i] = mixedColor.r;
            colors[i + 1] = mixedColor.g;
            colors[i + 2] = mixedColor.b;
        }

        particlesGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        particlesGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

        const particlesMaterial = new THREE.PointsMaterial({
            size: 0.2,
            vertexColors: true,
            transparent: true,
            opacity: 0.6,
            sizeAttenuation: true
        });

        this.particles = new THREE.Points(particlesGeometry, particlesMaterial);
        this.scene.add(this.particles);
    }

    onWindowResize() {
        this.camera.aspect = window.innerWidth / window.innerHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(window.innerWidth, window.innerHeight);
    }

    render() {
        // Animate background
        if (this.particles) {
            this.particles.rotation.y += 0.0005;
            this.particles.rotation.x += 0.0002;
        }

        this.renderer.render(this.scene, this.camera);
    }
}
