import { THEMES } from './themes.js';

export class ThemeManager {
    constructor(game) {
        this.game = game;
        this.currentTheme = 'classic';

        // Load saved theme
        const saved = localStorage.getItem('magic_cube_theme');
        if (saved && THEMES[saved]) {
            this.currentTheme = saved;
        }

        this.applyTheme(this.currentTheme);
    }

    applyTheme(themeKey) {
        if (!THEMES[themeKey]) return;

        const theme = THEMES[themeKey];
        this.currentTheme = themeKey;
        localStorage.setItem('magic_cube_theme', themeKey);

        // 1. Update CSS Variables
        const root = document.documentElement;
        root.style.setProperty('--theme-primary', theme.ui.primary);
        root.style.setProperty('--theme-secondary', theme.ui.secondary);
        root.style.setProperty('--theme-accent', theme.ui.accent);
        root.style.setProperty('--theme-bg', theme.background.bg);

        // 2. Update Cube Colors
        if (this.game.cube) {
            this.game.cube.setColors(theme.colors);
        }

        // 3. Update Background
        if (this.game.sceneManager) {
            this.game.sceneManager.setBackground(theme.background);
        }
    }

    getCurrentTheme() {
        return this.currentTheme;
    }

    getThemes() {
        return THEMES;
    }
}
