export const THEMES = {
    classic: {
        name: 'Classic',
        colors: { U: 0xFFFFFF, D: 0xFFD700, L: 0xFF5800, R: 0xDC143C, F: 0x00FF7F, B: 0x1E90FF, Core: 0x1A1B26 },
        background: { type: 'particles', color1: 0x6C5DD3, color2: 0x00D4FF, bg: '#1F1D2B' },
        ui: { primary: '#6C5DD3', secondary: '#A0AEC0', accent: '#00D4FF' }
    },
    neon: {
        name: 'Neon',
        colors: { U: 0x00FFFF, D: 0xFF00FF, L: 0x39FF14, R: 0xFF3131, F: 0xFFFF00, B: 0x1F51FF, Core: 0x000000 },
        background: { type: 'particles', color1: 0xFF00FF, color2: 0x00FFFF, bg: '#050505' },
        ui: { primary: '#00FFFF', secondary: '#FF00FF', accent: '#39FF14' }
    },
    pastel: {
        name: 'Pastel',
        colors: { U: 0xFFB7B2, D: 0xFFDAC1, L: 0xE2F0CB, R: 0xB5EAD7, F: 0xC7CEEA, B: 0xF2D7D5, Core: 0x606060 },
        background: { type: 'gradient', color1: 0xFFDEE9, color2: 0xB5FFFC, bg: '#FFF0F5' },
        ui: { primary: '#FFB7B2', secondary: '#9E9E9E', accent: '#B5EAD7' }
    },
    monochrome: {
        name: 'Monochrome',
        colors: { U: 0xFFFFFF, D: 0x444444, L: 0xAAAAAA, R: 0x888888, F: 0xCCCCCC, B: 0x222222, Core: 0x000000 },
        background: { type: 'particles', color1: 0xFFFFFF, color2: 0x333333, bg: '#121212' },
        ui: { primary: '#FFFFFF', secondary: '#888888', accent: '#FF0000' }
    },
    gold: {
        name: 'Gold',
        colors: { U: 0xFFD700, D: 0xB8860B, L: 0xDAA520, R: 0xFFE4B5, F: 0xF0E68C, B: 0xEEE8AA, Core: 0x1C1C1C },
        background: { type: 'particles', color1: 0xFFD700, color2: 0xDAA520, bg: '#000000' },
        ui: { primary: '#FFD700', secondary: '#B8860B', accent: '#FFFFFF' }
    },
    ocean: {
        name: 'Ocean',
        colors: { U: 0xE0FFFF, D: 0x00CED1, L: 0x4682B4, R: 0x1E90FF, F: 0x000080, B: 0x87CEEB, Core: 0x001f3f },
        background: { type: 'particles', color1: 0x00CED1, color2: 0x1E90FF, bg: '#001f3f' },
        ui: { primary: '#00CED1', secondary: '#87CEEB', accent: '#E0FFFF' }
    },
    forest: {
        name: 'Forest',
        colors: { U: 0xF0FFF0, D: 0x228B22, L: 0x8B4513, R: 0x006400, F: 0x32CD32, B: 0x556B2F, Core: 0x1a1a1a },
        background: { type: 'particles', color1: 0x228B22, color2: 0x32CD32, bg: '#0a1a0a' },
        ui: { primary: '#32CD32', secondary: '#8B4513', accent: '#F0FFF0' }
    },
    sunset: {
        name: 'Sunset',
        colors: { U: 0xFFD700, D: 0xFF4500, L: 0xFF6347, R: 0x800080, F: 0xFF1493, B: 0x4B0082, Core: 0x2c003e },
        background: { type: 'gradient', color1: 0xFF4500, color2: 0x800080, bg: '#2c003e' },
        ui: { primary: '#FF4500', secondary: '#FFD700', accent: '#FF1493' }
    },
    matrix: {
        name: 'Matrix',
        colors: { U: 0x00FF00, D: 0x003300, L: 0x008800, R: 0x00CC00, F: 0x005500, B: 0x00AA00, Core: 0x000000 },
        background: { type: 'particles', color1: 0x00FF00, color2: 0x003300, bg: '#000000' },
        ui: { primary: '#00FF00', secondary: '#003300', accent: '#FFFFFF' }
    },
    dracula: {
        name: 'Dracula',
        colors: { U: 0xF8F8F2, D: 0x6272A4, L: 0x8BE9FD, R: 0xFF5555, F: 0x50FA7B, B: 0xBD93F9, Core: 0x282A36 },
        background: { type: 'particles', color1: 0xBD93F9, color2: 0xFF5555, bg: '#282A36' },
        ui: { primary: '#BD93F9', secondary: '#6272A4', accent: '#FF79C6' }
    },
    cotton_candy: {
        name: 'Cotton Candy',
        colors: { U: 0xFFFFFF, D: 0xFFC0CB, L: 0x87CEFA, R: 0xFF69B4, F: 0x00BFFF, B: 0xFF1493, Core: 0xFFFFFF },
        background: { type: 'gradient', color1: 0xFFC0CB, color2: 0x87CEFA, bg: '#FFF0F5' },
        ui: { primary: '#FF69B4', secondary: '#87CEFA', accent: '#FFC0CB' }
    },
    lava: {
        name: 'Lava',
        colors: { U: 0xFF4500, D: 0x8B0000, L: 0xFF8C00, R: 0xCD5C5C, F: 0xA52A2A, B: 0x800000, Core: 0x1a0505 },
        background: { type: 'particles', color1: 0xFF4500, color2: 0x8B0000, bg: '#1a0505' },
        ui: { primary: '#FF4500', secondary: '#8B0000', accent: '#FF8C00' }
    },
    ice: {
        name: 'Ice',
        colors: { U: 0xF0FFFF, D: 0xE0FFFF, L: 0xAFEEEE, R: 0xADD8E6, F: 0x87CEFA, B: 0x4682B4, Core: 0xFFFFFF },
        background: { type: 'particles', color1: 0xE0FFFF, color2: 0x87CEFA, bg: '#F0FFFF' },
        ui: { primary: '#00BFFF', secondary: '#ADD8E6', accent: '#FFFFFF' }
    },
    midnight: {
        name: 'Midnight',
        colors: { U: 0xC0C0C0, D: 0x191970, L: 0x000080, R: 0x483D8B, F: 0x4169E1, B: 0x0000CD, Core: 0x000000 },
        background: { type: 'particles', color1: 0x191970, color2: 0x483D8B, bg: '#000010' },
        ui: { primary: '#4169E1', secondary: '#C0C0C0', accent: '#191970' }
    }
};
