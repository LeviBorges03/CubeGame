
import * as THREE from 'three';

export class Cube {
    constructor(scene, size = 3) {
        this.scene = scene;
        this.size = size;
        this.cubies = [];
        this.group = new THREE.Group();
        this.scene.add(this.group);

        // Colors based on standard Rubik's Cube + Design System aesthetics
        this.colors = {
            U: 0xFFFFFF, // Up - White
            D: 0xFFD500, // Down - Yellow
            L: 0xFF5800, // Left - Orange
            R: 0xB90000, // Right - Red
            F: 0x009E60, // Front - Green
            B: 0x0051BA, // Back - Blue
            Core: 0x1A1B26 // Inner - Dark
        };

        this.createCube();
    }

    createCube() {
        // Calculate offset to center the cube
        const offset = (this.size - 1) / 2;
        const geometry = new THREE.BoxGeometry(0.95, 0.95, 0.95);

        for (let x = 0; x < this.size; x++) {
            for (let y = 0; y < this.size; y++) {
                for (let z = 0; z < this.size; z++) {
                    // Adjust coordinates to be centered
                    const posX = x - offset;
                    const posY = y - offset;
                    const posZ = z - offset;

                    const materials = this.getMaterials(x, y, z);
                    const cubie = new THREE.Mesh(geometry, materials);
                    cubie.position.set(posX, posY, posZ);

                    // Store logical coordinates
                    cubie.userData = {
                        x: posX,
                        y: posY,
                        z: posZ,
                        initialX: x,
                        initialY: y,
                        initialZ: z,
                        isCubie: true
                    };

                    this.cubies.push(cubie);
                    this.group.add(cubie);
                }
            }
        }
    }

    getMaterials(x, y, z) {
        // x, y, z are 0-indexed indices here
        const last = this.size - 1;

        const m = (color) => new THREE.MeshStandardMaterial({
            color: color,
            roughness: 0.5,
            metalness: 0.1
        });

        const coreMat = m(this.colors.Core);

        return [
            x === last ? m(this.colors.R) : coreMat, // Right
            x === 0 ? m(this.colors.L) : coreMat,    // Left
            y === last ? m(this.colors.U) : coreMat, // Up
            y === 0 ? m(this.colors.D) : coreMat,    // Down
            z === last ? m(this.colors.F) : coreMat, // Front
            z === 0 ? m(this.colors.B) : coreMat     // Back
        ];
    }

    setColors(newColors) {
        this.colors = newColors;

        const m = (color) => new THREE.MeshStandardMaterial({
            color: color,
            roughness: 0.5,
            metalness: 0.1
        });

        const last = this.size - 1;

        this.cubies.forEach(cubie => {
            const { initialX, initialY, initialZ } = cubie.userData;

            // Dispose old materials
            if (Array.isArray(cubie.material)) {
                cubie.material.forEach(mat => mat.dispose());
            }

            const coreMat = m(this.colors.Core);

            cubie.material = [
                initialX === last ? m(this.colors.R) : coreMat, // Right
                initialX === 0 ? m(this.colors.L) : coreMat,    // Left
                initialY === last ? m(this.colors.U) : coreMat, // Up
                initialY === 0 ? m(this.colors.D) : coreMat,    // Down
                initialZ === last ? m(this.colors.F) : coreMat, // Front
                initialZ === 0 ? m(this.colors.B) : coreMat     // Back
            ];
        });
    }

    // Rotation Logic
    rotateLayer(axis, limit, direction, animationDuration = 500) {
        if (this.isRotating) return;
        this.isRotating = true;

        // 1. Find cubies in the layer
        // We need to handle floating point comparisons due to centering offsets
        const activeCubies = this.cubies.filter(c => Math.abs(c.userData[axis] - limit) < 0.1);

        // 2. Create a pivot object
        const pivot = new THREE.Object3D();
        pivot.rotation.set(0, 0, 0);
        this.group.add(pivot);

        // 3. Attach cubies to pivot
        activeCubies.forEach(c => {
            this.group.remove(c);
            pivot.add(c);
        });

        // 4. Animate
        const startRotation = { value: 0 };
        const targetRotation = { value: Math.PI / 2 * direction };

        const startTime = Date.now();

        const animate = () => {
            const now = Date.now();
            const progress = Math.min((now - startTime) / animationDuration, 1);

            // Ease out cubic
            const ease = 1 - Math.pow(1 - progress, 3);

            pivot.rotation.set(
                axis === 'x' ? targetRotation.value * ease : 0,
                axis === 'y' ? targetRotation.value * ease : 0,
                axis === 'z' ? targetRotation.value * ease : 0
            );

            if (progress < 1) {
                requestAnimationFrame(animate);
            } else {
                // 5. Cleanup
                pivot.updateMatrixWorld();
                activeCubies.forEach(c => {
                    c.updateMatrixWorld();
                    pivot.remove(c);
                    this.group.add(c);

                    // Apply transformation to mesh
                    c.position.applyMatrix4(pivot.matrixWorld);
                    c.quaternion.premultiply(pivot.quaternion);

                    // Round positions to handle floating point drift
                    // We need to be careful with rounding for even-sized cubes (0.5 coordinates)
                    // For even sizes, coordinates end in .5. For odd, they are integers.
                    // A generic way is to round to nearest 0.5 or just rely on the fact that 90 deg rotation preserves the grid

                    const roundToGrid = (val) => {
                        // If size is odd, round to integer. If even, round to .5
                        return Math.round(val * 2) / 2;
                    };

                    c.position.x = roundToGrid(c.position.x);
                    c.position.y = roundToGrid(c.position.y);
                    c.position.z = roundToGrid(c.position.z);

                    c.updateMatrix();

                    // Update logical coordinates
                    c.userData.x = c.position.x;
                    c.userData.y = c.position.y;
                    c.userData.z = c.position.z;
                });

                this.group.remove(pivot);
                this.isRotating = false;

                // Notify listener
                if (this.onMove) this.onMove();
            }
        };

        animate();
    }

    dispose() {
        // Clean up geometry and materials
        this.scene.remove(this.group);
        this.cubies.forEach(c => {
            c.geometry.dispose();
            if (Array.isArray(c.material)) {
                c.material.forEach(m => m.dispose());
            } else {
                c.material.dispose();
            }
        });
        this.cubies = [];
    }
}
