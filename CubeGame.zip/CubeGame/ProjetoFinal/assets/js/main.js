import { SceneManager } from './SceneManager.js';
import { Cube } from './Cube.js';
import { InputController } from './InputController.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { ThemeManager } from './ThemeManager.js';
import { ThemeSelector } from './ThemeSelector.js';
import { PuzzleSelector } from './PuzzleSelector.js';

class Game {
    constructor() {
        this.container = document.getElementById('game-container');
        this.sceneManager = new SceneManager(this.container);

        this.currentSize = 3;
        this.cube = new Cube(this.sceneManager.scene, this.currentSize);

        // Initialize Systems
        this.themeManager = new ThemeManager(this);
        this.themeSelector = new ThemeSelector(this.themeManager);
        this.puzzleSelector = new PuzzleSelector(this);

        this.controls = new OrbitControls(this.sceneManager.camera, this.sceneManager.renderer.domElement);
        this.controls.enableDamping = true;
        this.controls.autoRotate = true; // Auto rotate in intro
        this.controls.autoRotateSpeed = 2.0;

        this.inputController = new InputController(this, this.container);

        // Game State
        this.isPlaying = false;
        this.moves = 0;
        this.startTime = 0;
        this.timerInterval = null;

        this.setupUI();

        this.animate = this.animate.bind(this);
        this.animate();
    }

    setupUI() {
        // Elements
        this.introScreen = document.getElementById('intro-screen');
        this.gameUI = document.getElementById('game-ui');
        this.timerDisplay = document.getElementById('timer-display');
        this.moveDisplay = document.getElementById('move-display');

        // Puzzle Label (Logic moved to PuzzleSelector, but we keep reference if needed)
        this.puzzleLabel = document.getElementById('puzzle-label');

        // Buttons
        document.getElementById('btn-start').addEventListener('click', () => this.startGame());
        document.getElementById('btn-scramble').addEventListener('click', () => this.scramble());
        document.getElementById('btn-reset').addEventListener('click', () => this.resetGame());

        // Listen for cube moves
        this.cube.onMove = () => this.onCubeMove();
    }

    // Selector logic moved to PuzzleSelector.js

    setPuzzle(size) {
        if (this.currentSize === size) return;

        this.currentSize = size;
        this.puzzleLabel.textContent = `${size}x${size}x${size}`;

        // Dispose old cube
        this.cube.dispose();

        // Create new cube
        this.cube = new Cube(this.sceneManager.scene, this.currentSize);
        this.cube.onMove = () => this.onCubeMove();

        // Apply current theme to new cube
        if (this.themeManager) {
            this.themeManager.applyTheme(this.themeManager.currentTheme);
        }

        this.resetStats();
    }

    startGame() {
        this.introScreen.classList.remove('active');
        this.gameUI.classList.remove('hidden');

        this.controls.autoRotate = false;
        this.controls.reset(); // Reset camera to default

        this.isPlaying = true;
        this.resetStats();
    }

    resetGame() {
        // Instead of reload, just reset the current puzzle
        this.cube.dispose();
        this.cube = new Cube(this.sceneManager.scene, this.currentSize);
        this.cube.onMove = () => this.onCubeMove();

        // Apply current theme to new cube
        if (this.themeManager) {
            this.themeManager.applyTheme(this.themeManager.currentTheme);
        }

        this.resetStats();
    }

    onCubeMove() {
        if (!this.isPlaying) return;

        this.moves++;
        this.moveDisplay.textContent = this.moves;

        if (!this.timerInterval) {
            this.startTimer();
        }
    }

    startTimer() {
        this.startTime = Date.now();
        this.timerInterval = setInterval(() => {
            const delta = Date.now() - this.startTime;
            const seconds = Math.floor(delta / 1000);
            const minutes = Math.floor(seconds / 60);
            const secs = seconds % 60;
            this.timerDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        }, 1000);
    }

    stopTimer() {
        clearInterval(this.timerInterval);
        this.timerInterval = null;
    }

    resetStats() {
        this.moves = 0;
        this.moveDisplay.textContent = '0';
        this.stopTimer();
        this.timerDisplay.textContent = '00:00';
    }

    scramble() {
        let moves = 0;
        const maxMoves = 20;

        const axes = ['x', 'y', 'z'];
        const dirs = [1, -1];

        // Generate valid limits based on size
        const limits = [];
        const offset = (this.currentSize - 1) / 2;

        // We want to rotate layers. In our system, layers are at integer/half-integer coordinates.
        // For size 3 (offset 1): coords are -1, 0, 1.
        // For size 2 (offset 0.5): coords are -0.5, 0.5.
        for (let i = 0; i < this.currentSize; i++) {
            limits.push(i - offset);
        }

        const interval = setInterval(() => {
            if (moves >= maxMoves) {
                clearInterval(interval);
                this.resetStats();
                return;
            }

            const axis = axes[Math.floor(Math.random() * axes.length)];
            const limit = limits[Math.floor(Math.random() * limits.length)];
            const dir = dirs[Math.floor(Math.random() * dirs.length)];

            this.cube.rotateLayer(axis, limit, dir, 100); // Fast rotation
            moves++;
        }, 150);
    }

    animate() {
        requestAnimationFrame(this.animate);
        this.controls.update();
        this.sceneManager.render();
    }
}

window.addEventListener('DOMContentLoaded', () => {
    new Game();
});
