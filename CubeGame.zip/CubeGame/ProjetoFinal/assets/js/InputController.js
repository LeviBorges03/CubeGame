import * as THREE from 'three';

export class InputController {
    constructor(game, container) {
        this.game = game;
        this.container = container;
        this.raycaster = new THREE.Raycaster();
        this.mouse = new THREE.Vector2();

        this.isDragging = false;
        this.startMouse = new THREE.Vector2();
        this.intersectedCubie = null;
        this.startFaceNormal = null;

        this.container.addEventListener('mousedown', this.onMouseDown.bind(this));
        this.container.addEventListener('mousemove', this.onMouseMove.bind(this));
        this.container.addEventListener('mouseup', this.onMouseUp.bind(this));
    }

    getIntersects(event) {
        const rect = this.container.getBoundingClientRect();
        this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
        this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

        this.raycaster.setFromCamera(this.mouse, this.game.sceneManager.camera);
        return this.raycaster.intersectObjects(this.game.cube.cubies);
    }

    onMouseDown(event) {
        const intersects = this.getIntersects(event);
        if (intersects.length > 0) {
            // Disable orbit controls if we clicked a cubie
            this.game.controls.enabled = false;

            this.isDragging = true;
            this.intersectedCubie = intersects[0].object;
            this.startFaceNormal = intersects[0].face.normal.clone();
            // Transform normal to world space if needed, but for a cube aligned to axes, it's fine usually.
            // Actually, since the cube rotates, we need to be careful.
            // For now, let's just store the start mouse position.
            this.startMouse.set(event.clientX, event.clientY);
        } else {
            this.game.controls.enabled = true;
        }
    }

    onMouseMove(event) {
        if (!this.isDragging || !this.intersectedCubie) return;

        const deltaX = event.clientX - this.startMouse.x;
        const deltaY = event.clientY - this.startMouse.y;

        // Minimum drag distance
        if (Math.abs(deltaX) < 10 && Math.abs(deltaY) < 10) return;

        // Determine direction
        // This is a simplified version. A full implementation needs to project the drag vector onto the screen
        // and compare with the face normal to determine the axis of rotation.

        // For this MVP, let's try a simple heuristic based on the face normal.
        // If normal is Y (Up/Down), drag X -> rotate Z, drag Y -> rotate X? No, drag Y -> rotate X.

        // Let's implement a simple test:
        // If we clicked a side face (Normal X or Z), vertical drag rotates the side face around X or Z?
        // No, vertical drag rotates around X (if normal is Z) or Z (if normal is X).

        // Let's just trigger a random rotation for testing the animation first? No, that's bad UX.

        // Better heuristic:
        // 1. Get the normal of the clicked face.
        // 2. If normal is Y (Top/Bottom):
        //    - Horizontal drag (deltaX) -> Rotate around Z (or X?) -> Actually rotates around Y axis? No, that rotates the whole cube.
        //    - We want to rotate a slice.
        //    - Horizontal drag -> Rotates the slice around Z axis? No.

        // Let's stick to a simpler control scheme for now:
        // Click a face, drag in the direction of the row/column you want to move.

        // Implementation:
        // We have the clicked cubie.
        // We have the drag direction (Screen space).
        // We need to map screen drag to 3D axis.

        // Simplified: 
        // Just use UI buttons for scrambling for now to verify logic, 
        // OR implement a very basic "drag right = rotate Y clockwise" for the whole cube? No, we have OrbitControls for that.

        // Let's try to infer the axis.
        // If |deltaX| > |deltaY|, we are moving horizontally.
        // If we clicked the Front face (Z+), horizontal move = Rotate around Y axis.

        let axis, direction;

        // Normalize normal to world space (approximate since we only rotate 90 deg)
        // Actually, we can use the logical position to determine the face.

        // Let's assume we are looking somewhat from the front-right-top.

        // Trigger a rotation and stop dragging
        // Example: Rotate the slice containing the intersected cubie.

        // Debug: Rotate the whole face of the cubie we clicked.
        // If we clicked a cubie at x=1, rotate the R face.

        const { x, y, z } = this.intersectedCubie.userData;

        // Heuristic for MVP:
        // If drag is horizontal:
        //    Rotate around Y axis (Top/Bottom layers)
        // If drag is vertical:
        //    Rotate around X axis (Left/Right layers)

        if (Math.abs(deltaX) > Math.abs(deltaY)) {
            // Horizontal drag
            axis = 'y';
            direction = deltaX > 0 ? -1 : 1; // Drag right -> Rotate counter-clockwise (viewed from top)
            this.game.cube.rotateLayer('y', y, direction);
        } else {
            // Vertical drag
            axis = 'x';
            direction = deltaY > 0 ? -1 : 1;
            this.game.cube.rotateLayer('x', x, direction);
        }

        this.isDragging = false;
        this.intersectedCubie = null;
        this.game.controls.enabled = true;
    }

    onMouseUp() {
        this.isDragging = false;
        this.intersectedCubie = null;
        this.game.controls.enabled = true;
    }
}
