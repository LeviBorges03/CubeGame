// ============================================================================
// CONSTELLATION EFFECT - INTERACTIVE PARTICLE SYSTEM
// Partículas conectadas que formam constelações e reagem ao mouse
// ============================================================================

class ConstellationEffect {
    constructor() {
        this.canvas = document.getElementById('particle-canvas');
        if (!this.canvas) {
            console.error('Canvas não encontrado!');
            return;
        }

        this.ctx = this.canvas.getContext('2d');
        this.particles = [];
        this.maxParticles = 50;
        this.mouse = { x: null, y: null };
        this.isPaused = false;
        this.lastFrameTime = performance.now();
        this.fps = 60;

        // Cores temáticas (cores do cubo mágico)
        this.colors = [
            '#DC2626', // Vermelho
            '#EA580C', // Laranja
            '#FBBF24', // Amarelo
            '#16A34A', // Verde
            '#2563EB', // Azul
            '#F9FAFB'  // Branco
        ];

        this.init();
    }

    init() {
        this.resizeCanvas();
        this.createParticles();
        this.setupEventListeners();
        this.setupControls();
        this.animate();
        console.log('✨ Constellation Effect Initialized');
    }

    resizeCanvas() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
    }

    setupEventListeners() {
        // Resize
        window.addEventListener('resize', () => {
            this.resizeCanvas();
        });

        // Mouse tracking
        window.addEventListener('mousemove', (e) => {
            this.mouse.x = e.clientX;
            this.mouse.y = e.clientY;
        });

        window.addEventListener('mouseleave', () => {
            this.mouse.x = null;
            this.mouse.y = null;
        });

        // Touch support
        window.addEventListener('touchmove', (e) => {
            if (e.touches.length > 0) {
                this.mouse.x = e.touches[0].clientX;
                this.mouse.y = e.touches[0].clientY;
            }
        });

        window.addEventListener('touchend', () => {
            this.mouse.x = null;
            this.mouse.y = null;
        });
    }

    setupControls() {
        const resetBtn = document.getElementById('resetBtn');
        const toggleBtn = document.getElementById('toggleBtn');

        resetBtn?.addEventListener('click', () => {
            this.particles = [];
            this.createParticles();
            console.log('🔄 Partículas resetadas');
        });

        toggleBtn?.addEventListener('click', () => {
            this.isPaused = !this.isPaused;
            toggleBtn.textContent = this.isPaused ? '▶️ Continuar' : '⏸️ Pausar';
            console.log(this.isPaused ? '⏸️ Pausado' : '▶️ Continuando');
        });
    }

    createParticles() {
        for (let i = 0; i < this.maxParticles; i++) {
            this.particles.push(new Particle(this));
        }
    }

    animate() {
        // Calcular FPS
        const now = performance.now();
        const delta = now - this.lastFrameTime;
        this.fps = Math.round(1000 / delta);
        this.lastFrameTime = now;

        // Atualizar UI
        this.updateUI();

        if (!this.isPaused) {
            // Limpar canvas
            this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

            // Atualizar e desenhar partículas
            this.particles.forEach(particle => {
                particle.update();
                particle.draw();
            });

            // Conectar partículas próximas (efeito de constelação)
            this.connectParticles();
        }

        requestAnimationFrame(() => this.animate());
    }

    connectParticles() {
        for (let i = 0; i < this.particles.length; i++) {
            for (let j = i + 1; j < this.particles.length; j++) {
                const p1 = this.particles[i];
                const p2 = this.particles[j];
                const dx = p1.x - p2.x;
                const dy = p1.y - p2.y;
                const distance = Math.sqrt(dx * dx + dy * dy);

                // Conectar se estiverem próximas
                if (distance < 150) {
                    const opacity = 1 - (distance / 150);
                    this.ctx.strokeStyle = `rgba(139, 92, 246, ${opacity * 0.3})`;
                    this.ctx.lineWidth = 1;
                    this.ctx.beginPath();
                    this.ctx.moveTo(p1.x, p1.y);
                    this.ctx.lineTo(p2.x, p2.y);
                    this.ctx.stroke();
                }
            }
        }
    }

    updateUI() {
        const particleCount = document.getElementById('particleCount');
        const fpsCounter = document.getElementById('fpsCounter');

        if (particleCount) particleCount.textContent = this.particles.length;
        if (fpsCounter) fpsCounter.textContent = this.fps;
    }
}

// ============================================================================
// PARTICLE CLASS
// ============================================================================

class Particle {
    constructor(system) {
        this.system = system;
        this.reset();
    }

    reset() {
        this.x = Math.random() * this.system.canvas.width;
        this.y = Math.random() * this.system.canvas.height;
        this.size = Math.random() * 4 + 2;
        this.speedX = (Math.random() - 0.5) * 2;
        this.speedY = (Math.random() - 0.5) * 2;
        this.color = this.system.colors[Math.floor(Math.random() * this.system.colors.length)];
        this.rotation = Math.random() * Math.PI * 2;
        this.rotationSpeed = (Math.random() - 0.5) * 0.02;
    }

    update() {
        // Interação com mouse
        if (this.system.mouse.x !== null && this.system.mouse.y !== null) {
            const dx = this.system.mouse.x - this.x;
            const dy = this.system.mouse.y - this.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            const maxDistance = 150;

            if (distance < maxDistance) {
                // Repelir partículas do mouse
                const force = (maxDistance - distance) / maxDistance;
                const angle = Math.atan2(dy, dx);
                this.speedX -= Math.cos(angle) * force * 0.5;
                this.speedY -= Math.sin(angle) * force * 0.5;
            }
        }

        // Mover partícula
        this.x += this.speedX;
        this.y += this.speedY;
        this.rotation += this.rotationSpeed;

        // Aplicar fricção
        this.speedX *= 0.98;
        this.speedY *= 0.98;

        // Bounce nas bordas
        if (this.x < 0 || this.x > this.system.canvas.width) {
            this.speedX *= -1;
            this.x = Math.max(0, Math.min(this.system.canvas.width, this.x));
        }
        if (this.y < 0 || this.y > this.system.canvas.height) {
            this.speedY *= -1;
            this.y = Math.max(0, Math.min(this.system.canvas.height, this.y));
        }

        // Manter velocidade mínima
        const minSpeed = 0.1;
        if (Math.abs(this.speedX) < minSpeed) this.speedX = (Math.random() - 0.5) * minSpeed * 2;
        if (Math.abs(this.speedY) < minSpeed) this.speedY = (Math.random() - 0.5) * minSpeed * 2;
    }

    draw() {
        const ctx = this.system.ctx;

        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.rotation);

        // Desenhar cubo pequeno em 3D isométrico
        const halfSize = this.size / 2;

        // Face frontal
        ctx.fillStyle = this.color;
        ctx.fillRect(-halfSize, -halfSize, this.size, this.size);

        // Face superior (mais clara)
        ctx.fillStyle = this.lightenColor(this.color, 20);
        ctx.beginPath();
        ctx.moveTo(-halfSize, -halfSize);
        ctx.lineTo(0, -halfSize - halfSize * 0.5);
        ctx.lineTo(halfSize, -halfSize);
        ctx.closePath();
        ctx.fill();

        // Face direita (mais escura)
        ctx.fillStyle = this.darkenColor(this.color, 20);
        ctx.beginPath();
        ctx.moveTo(halfSize, -halfSize);
        ctx.lineTo(halfSize + halfSize * 0.5, 0);
        ctx.lineTo(halfSize, halfSize);
        ctx.closePath();
        ctx.fill();

        // Efeito de brilho
        ctx.shadowBlur = 10;
        ctx.shadowColor = this.color;

        ctx.restore();
    }

    lightenColor(color, percent) {
        const num = parseInt(color.replace('#', ''), 16);
        const amt = Math.round(2.55 * percent);
        const R = Math.min(255, (num >> 16) + amt);
        const G = Math.min(255, ((num >> 8) & 0x00FF) + amt);
        const B = Math.min(255, (num & 0x0000FF) + amt);
        return `rgb(${R}, ${G}, ${B})`;
    }

    darkenColor(color, percent) {
        const num = parseInt(color.replace('#', ''), 16);
        const amt = Math.round(2.55 * percent);
        const R = Math.max(0, (num >> 16) - amt);
        const G = Math.max(0, ((num >> 8) & 0x00FF) - amt);
        const B = Math.max(0, (num & 0x0000FF) - amt);
        return `rgb(${R}, ${G}, ${B})`;
    }
}

// ============================================================================
// INICIALIZAÇÃO
// ============================================================================

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.constellationEffect = new ConstellationEffect();
    });
} else {
    window.constellationEffect = new ConstellationEffect();
}

console.log('🌟 Constellation Effect Module Loaded');
