# ✨ Constellation Effect

Um efeito visual impressionante de partículas conectadas que formam constelações dinâmicas e reagem ao movimento do mouse.

## 🎯 Características

- **Partículas Animadas**: 50 aumentar pra 100 partículas coloridas em movimento constante
- **Conexões Dinâmicas**: Linhas que conectam partículas próximas formando constelações
- **Interação com Mouse**: Partículas são repelidas quando o mouse se aproxima
- **Cubos 3D Isométricos**: Cada partícula é renderizada como um cubo 3D com rotação
- **Performance Otimizada**: Roda suavemente a 60 FPS
- **Controles Interativos**: Pausar/continuar e resetar o efeito
- **Responsivo**: Funciona em qualquer tamanho de tela
- **Suporte Touch**: Totalmente funcional em dispositivos móveis

## 📁 Estrutura de Arquivos

```
ConstellationEffect/
├── index.html          # Página HTML principal
├── style.css           # Estilos com glassmorphism
├── constellation.js    # Sistema de partículas completo
└── README.md          # Esta documentação
```

## 🚀 Como Usar

1. **Abrir o Efeito**:
   - Simplesmente abra `index.html` em qualquer navegador moderno
   - Não requer servidor web ou dependências externas

2. **Controles Disponíveis**:
   - **Resetar**: Recria todas as partículas em novas posições
   - **Pausar/Continuar**: Pausa ou retoma a animação

3. **Interação**:
   - Mova o mouse pela tela para ver as partículas reagirem
   - As partículas são repelidas quando o mouse se aproxima
   - Conexões se formam automaticamente entre partículas próximas

## 🎨 Personalização

### Alterar Número de Partículas

No arquivo `constellation.js`, linha 16:
```javascript
this.maxParticles = 50; // Altere para o número desejado
```

### Mudar Cores das Partículas

No arquivo `constellation.js`, linhas 23-30:
```javascript
this.colors = [
    '#DC2626', // Vermelho
    '#EA580C', // Laranja
    '#FBBF24', // Amarelo
    '#16A34A', // Verde
    '#2563EB', // Azul
    '#F9FAFB'  // Branco
];
```

### Ajustar Distância de Conexão

No arquivo `constellation.js`, linha 139:
```javascript
if (distance < 150) { // Altere 150 para o raio desejado
```

### Modificar Força de Repulsão do Mouse

No arquivo `constellation.js`, linhas 202-203:
```javascript
this.speedX -= Math.cos(angle) * force * 0.5; // Altere 0.5 para ajustar força
this.speedY -= Math.sin(angle) * force * 0.5;
```

## 🛠️ Tecnologias Utilizadas

- **HTML5 Canvas**: Para renderização das partículas
- **JavaScript ES6+**: Classes, arrow functions, template literals
- **CSS3**: Glassmorphism, gradientes, animações
- **Vanilla JS**: Sem dependências ou frameworks

## 💡 Conceitos Técnicos

### Sistema de Partículas

- Cada partícula tem posição, velocidade, rotação e cor próprias
- Movimentação baseada em física com fricção e bouncing
- Velocidade mínima garantida para evitar partículas paradas

### Algoritmo de Conexão

- Verifica distância entre todos os pares de partículas (O(n²))
- Cria linhas com opacidade baseada na distância
- Otimizado com early return quando distância > 150px

### Interação com Mouse

- Cálculo de vetor de distância mouse-partícula
- Aplicação de força inversamente proporcional à distância
- Smooth movement com interpolação de velocidade

## 📊 Performance

- **FPS Target**: 60 FPS
- **Partículas**: 50 (configurável)
- **Conexões**: Dinâmicas, calculadas em tempo real
- **Memory**: ~2MB de uso de memória
- **CPU**: Otimizado com requestAnimationFrame

## 🌟 Possíveis Melhorias

- [ ] Adicionar controle de velocidade das partículas
- [ ] Implementar diferentes modos de interação (atrair vs repelir)
- [ ] Adicionar trilhas de partículas
- [ ] Criar presets de cores temáticas
- [ ] Adicionar modo "explosão" quando clicar
- [ ] Implementar spatial hashing para otimizar conexões

## 📝 Licença

Livre para uso pessoal e comercial. Criado como parte de uma coleção de efeitos web.

---

**Desenvolvido com ❤️ e JavaScript puro**
